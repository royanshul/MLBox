.. include:: ../python-package/README.rst
